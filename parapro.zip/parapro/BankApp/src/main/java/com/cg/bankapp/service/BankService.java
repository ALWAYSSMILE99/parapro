package com.cg.bankapp.service;


import java.util.List;

import com.cg.bankapp.bean.Bank;
import com.cg.bankapp.exception.BankException;


public interface BankService 
{	
	public void getDetailsbyLogin(String username,String password)throws BankException;
	public Bank addBankAccount(Bank bank) throws BankException;
	public double showBalance(int accountId) throws BankException;
	public double depositAmount(int accountId,double deposit) throws BankException;
	public double withdrawAmount(int accountId,double withdraw) throws BankException;
	public Bank cashTransfer(int source,int destination,double money) throws BankException;		
}
