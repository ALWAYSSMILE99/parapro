import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {

 constructor(private httpClient:HttpClient) { }
 
 public showBalance(accountnum): Observable<number>
 {
 console.log(accountnum);
 return this.httpClient.get<number>("http://localhost:9090/user/show/" + accountnum)
 }

 
 public createBankAccount(userDetails) {
 return this.httpClient.post<Customer>("http://localhost:9090/user/add", userDetails);
 }

 public depositAmount(accountnum,amount): Observable<number>
 {
 console.log(accountnum);
 let url = 'http://localhost:9090/user/deposit/'+accountnum+'/'+amount;
 return this.httpClient.put<number>(url,"");
 }
 
 public withdrawAmount(accountnum,amount): Observable<number>
 {
 console.log(accountnum);
 let url = 'http://localhost:9090/user/withdraw/'+accountnum+'/'+amount;
 return this.httpClient.put<number>(url,"");
 }

 public cashTransfer(source,destination,amount): Observable<number>
 {
   let url = 'http://localhost:9090/user/transfer/'+source+'/'+destination+'/'+amount;
   console.log(url);
   return this.httpClient.get<number>(url);
 }
 
 
}
